/* STM8L152C6.h */
#ifdef MCU_NAME
#define STM8L152C6 1
#endif
#include "STM8L152.h"
